import {Pixie} from '../src/pixie';

export default Pixie;
