import {createSvgIcon} from '../create-svg-icon';

export const EMobiledataIcon = createSvgIcon(
  <path d="M16 9V7H8v10h8v-2h-6v-2h6v-2h-6V9h6z" />
, 'EMobiledataOutlined');
