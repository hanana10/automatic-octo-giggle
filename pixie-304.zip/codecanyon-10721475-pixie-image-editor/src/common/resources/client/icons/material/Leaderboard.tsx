import {createSvgIcon} from '../create-svg-icon';

export const LeaderboardIcon = createSvgIcon(
  <path d="M16 11V3H8v6H2v12h20V11h-6zm-6-6h4v14h-4V5zm-6 6h4v8H4v-8zm16 8h-4v-6h4v6z" />
, 'LeaderboardOutlined');
