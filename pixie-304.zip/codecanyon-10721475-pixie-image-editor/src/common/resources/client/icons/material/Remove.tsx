import {createSvgIcon} from '../create-svg-icon';

export const RemoveIcon = createSvgIcon(
  <path d="M19 13H5v-2h14v2z" />
, 'RemoveOutlined');
